module github.com/gnomegl/jsdump

go 1.25.6

require (
	github.com/deckarep/golang-set/v2 v2.8.0 // indirect
	github.com/go-jose/go-jose/v3 v3.0.4 // indirect
	github.com/go-stack/stack v1.8.1 // indirect
	github.com/playwright-community/playwright-go v0.5700.1 // indirect
)
